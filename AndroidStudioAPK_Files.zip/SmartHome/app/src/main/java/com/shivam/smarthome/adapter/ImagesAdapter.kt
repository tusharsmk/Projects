package com.shivam.smarthome.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.shivam.smarthome.models.Images
import com.shivam.smarthome.R

class ImagesAdapter(mContext: Context, mUsers: List<Images>, isImage: Boolean) :
    RecyclerView.Adapter<ImagesAdapter.ViewHolder>() {
    private val mContext: Context
    private val mImages: List<Images>


    init {
        this.mImages = mUsers
        this.mContext = mContext
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view: View = LayoutInflater.from(mContext).inflate(R.layout.image_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val image: Images = mImages[position]
        Glide.with(mContext).load(image.URL).into(holder.imageView)
    }

    override fun getItemCount(): Int {
        return mImages.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var imageView: ImageView

        init {
            imageView = itemView.findViewById(R.id.image)
        }
    }
}