package com.shivam.smarthome

import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.animation.TranslateAnimation
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.*
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.shivam.smarthome.adapter.ImagesAdapter
import com.shivam.smarthome.models.Images


class MainActivity : AppCompatActivity() {

//    private lateinit var firebaseUser: FirebaseUser
    private lateinit var reference: DatabaseReference
    private lateinit var reference2: DatabaseReference
    private lateinit var reference3: DatabaseReference
    private lateinit var firebaseStorage:FirebaseStorage
    private lateinit var auth: FirebaseAuth

    private lateinit var floatButton: FloatingActionButton
    private lateinit var recyclerView: RecyclerView
    private lateinit var imageView:ImageView
    private lateinit var imagesAdapter: ImagesAdapter
    private lateinit var relativeLayout: RelativeLayout
    private lateinit var allow:Button
    private lateinit var deny:Button
    private lateinit var status:TextView

    private var mImages: ArrayList<Images>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        auth = Firebase.auth
        reference = FirebaseDatabase.getInstance().getReference("latest")
        reference2 = FirebaseDatabase.getInstance().getReference("test").child("append")
        reference3 = FirebaseDatabase.getInstance().getReference("switch")
        firebaseStorage= FirebaseStorage.getInstance()

        val currentUser = auth.currentUser
        if(currentUser == null){
            auth.signInWithEmailAndPassword("kclasher344@gmail.com", "himanshu.1")
                .addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) {
                        // Sign in success, update UI with the signed-in user's information
//                        Log.d(TAG, "signInWithEmail:success")
                        val user = auth.currentUser
//                        updateUI(user)
                    } else {
                        // If sign in fails, display a message to the user.
                        Log.w("TAG", "signInWithEmail:failure", task.exception)
                        Toast.makeText(baseContext, "Authentication failed.",
                            Toast.LENGTH_SHORT).show()
//                        updateUI(null)
                    }
                }
        }else{



            reference.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {

//                Log.d("MyTag",dataSnapshot.value.toString())
                    Glide.with(this@MainActivity).load(dataSnapshot.value.toString()).into(imageView)
                }

                override fun onCancelled(databaseError: DatabaseError) {}
            })

            reference3.child("switch_status").addValueEventListener(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    if (dataSnapshot.value.toString()=="1"){
                        status.text="Status - Door Open"
                    }
                    else if (dataSnapshot.value.toString()=="0"){
                        status.text="Status - Door Close"
                    }
                    Log.d("MyTag",dataSnapshot.value.toString())
                }

                override fun onCancelled(databaseError: DatabaseError) {}
            })


        }




        floatButton=findViewById(R.id.fab_show_images)
        recyclerView=findViewById(R.id.recycler_view)
        imageView=findViewById(R.id.image_view)
        relativeLayout=findViewById(R.id.currentImage)
        allow=findViewById(R.id.allow)
        deny=findViewById(R.id.deny)
        status=findViewById(R.id.status1)

        recyclerView.setHasFixedSize(true)
        recyclerView.layoutManager = GridLayoutManager(this,2)
        getImages()


        allow.setOnClickListener {

            reference3.child("switch_status").setValue("1")
            reference3.child("switch_status").addValueEventListener(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {

                    Log.d("MyTag",dataSnapshot.value.toString())
                                    }

                override fun onCancelled(databaseError: DatabaseError) {}
            })

        }
        deny.setOnClickListener {

            reference3.child("switch_status").setValue("0")
            reference3.child("switch_status").addValueEventListener(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {

                    Log.d("MyTag",dataSnapshot.value.toString())
                }

                override fun onCancelled(databaseError: DatabaseError) {}
            })

        }

        floatButton.setOnClickListener {
            if (recyclerView.visibility==View.GONE){
                floatButton.setImageResource(R.drawable.ic_baseline_arrow_upward_24)
                relativeLayout.visibility=View.GONE
                recyclerView.visibility=View.VISIBLE
                slideDown(relativeLayout)
                slideUp(recyclerView)
            }else{
                floatButton.setImageResource(R.drawable.ic_baseline_arrow_downward_24)
                recyclerView.visibility=View.GONE
                slideDown(recyclerView)
                slideUp(relativeLayout)
//                imageView.visibility=View.VISIBLE

            }

        }

    }

    private fun getImages() {
        mImages = ArrayList<Images>()
        reference2.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                mImages?.clear()
//                Log.d("MyTag","DataBase Snapshot is "+dataSnapshot)
                for (snapshot in dataSnapshot.children) {
                    val image: Images? = snapshot.getValue(Images::class.java)
//                    Log.d("MyTag",image?.URL.toString())
                    if (image != null) {
                        mImages!!.add(image)
                    }
                }
                imagesAdapter = ImagesAdapter(this@MainActivity, mImages!!, true)
                recyclerView.adapter = imagesAdapter
            }

            override fun onCancelled(databaseError: DatabaseError) {
                Log.d("MyTag",databaseError.message)
            }
        })
    }


    // slide the view from below itself to the current position
    private fun slideUp(view: View) {
//        view.visibility = View.VISIBLE
        val animate = TranslateAnimation(
            0F,  // fromXDelta
            0F,  // toXDelta
            view.height.toFloat(),  // fromYDelta
            0F
        ) // toYDelta
        animate.duration = 500
        animate.fillAfter = true
        view.startAnimation(animate)
    }

    // slide the view from its current position to below itself
    private fun slideDown(view: View) {
        val animate = TranslateAnimation(
            0F,  // fromXDelta
            0F,  // toXDelta
            0F,  // fromYDelta
            view.height.toFloat()
        ) // toYDelta
        animate.duration = 500
        animate.fillAfter = true
        view.startAnimation(animate)

    }

//    fun onSlideViewButtonClick(view: View?) {
//        if (isUp) {
//            slideDown(myView)
//            myButton.setText("Slide up")
//        } else {
//            slideUp(myView)
//            myButton.setText("Slide down")
//        }
//        isUp = !isUp
//    }


}