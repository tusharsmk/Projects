package com.shivam.smarthome.models

data class Images(val URL:String="") {}