package com.shivam.smarthome.models

data class LatestData(val image:String,val req:String)

